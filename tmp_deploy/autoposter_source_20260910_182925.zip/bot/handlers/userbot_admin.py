from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import BaseFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import func, select

from bot.services.emoji import apply_text, dumps_map, extract_from_message, loads_map, set_map
from bot.services.userbot import (
    HELLO_DEFAULT,
    begin_login,
    create_account,
    delete_account,
    is_online,
    list_accounts,
    set_active,
    status_label,
    submit_code,
    submit_password,
    update_texts,
)
from bot.services.userbot_format import dumps_entities, entities_from_aiogram
from bot.states import AdminSG
from config import settings
from database import SessionLocal
from database.crud import get_setting, set_setting
from database.models import UserBotAccount, UserBotLead

router = Router(name="userbot_admin")


class IsAdmin(BaseFilter):
    async def __call__(self, event: Message | CallbackQuery) -> bool:
        user = event.from_user
        return bool(user and settings.is_admin(user.id))


router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())

SKIP = {"/admin", "/start"}


async def _merge_premium(message: Message) -> None:
    found = extract_from_message(message)
    if not found:
        return
    async with SessionLocal() as session:
        current = loads_map(await get_setting(session, "premium_emojis", "{}"))
        current.update(found)
        await set_setting(session, "premium_emojis", dumps_map(current))
        await session.commit()
        set_map(current)


async def _ub_list_view() -> tuple[str, InlineKeyboardMarkup]:
    api_ok = bool(int(settings.api_id or 0) and (settings.api_hash or "").strip())
    rows = await list_accounts()
    async with SessionLocal() as session:
        lead_counts = dict(
            (await session.execute(select(UserBotLead.account_id, func.count()).group_by(UserBotLead.account_id))).all()
        )
    lines = [
        "🤖 <b>Юзер-бот</b>\n",
        "ЛС → привет → ответ/1ч → подарок → дожим 30м / 6ч / 24ч.\n",
    ]
    if not api_ok:
        lines.append("⚠️ В <code>.env</code> нужны <code>API_ID</code> и <code>API_HASH</code> (my.telegram.org)\n")
    if not rows:
        lines.append("Пока нет аккаунтов.")
    kb: list[list[InlineKeyboardButton]] = []
    for row in rows:
        uname = f"@{row.username}" if row.username else row.phone
        mark = "🟢" if is_online(row.id) else "⚪"
        n = int(lead_counts.get(row.id) or 0)
        kb.append(
            [
                InlineKeyboardButton(
                    text=f"{mark} {status_label(row)} · {uname} · {n}",
                    callback_data=f"adm:ub:v:{row.id}",
                )
            ]
        )
    kb.append([InlineKeyboardButton(text="➕ Добавить аккаунт", callback_data="adm:ub:add")])
    kb.append([InlineKeyboardButton(text="⬅️ Админка", callback_data="adm:root")])
    return "\n".join(lines), InlineKeyboardMarkup(inline_keyboard=kb)


async def _ub_card(account_id: int) -> tuple[str, InlineKeyboardMarkup] | None:
    async with SessionLocal() as session:
        row = await session.get(UserBotAccount, account_id)
        if not row:
            return None
        leads = int(
            (
                await session.execute(
                    select(func.count()).select_from(UserBotLead).where(UserBotLead.account_id == account_id)
                )
            ).scalar()
            or 0
        )
        gifted = int(
            (
                await session.execute(
                    select(func.count())
                    .select_from(UserBotLead)
                    .where(UserBotLead.account_id == account_id, UserBotLead.stage.in_(("gifted", "done")))
                )
            ).scalar()
            or 0
        )
        gift_preview = (row.gift_text or "").strip()
        if len(gift_preview) > 180:
            gift_preview = gift_preview[:180] + "…"
        gift_preview = gift_preview or "<i>не задан</i>"
        hello = apply_text(row.hello_text or HELLO_DEFAULT)
        online = "🟢 онлайн" if is_online(row.id) else f"⚪ {status_label(row)}"
        text = (
            f"🤖 <b>Юзер-бот #{row.id}</b>\n\n"
            f"Тел: <code>{row.phone}</code>\n"
            f"TG: <code>{row.tg_id or '—'}</code> @{row.username or '—'}\n"
            f"Статус: {online}\n"
            f"Диалогов: <b>{leads}</b> · подарков: <b>{gifted}</b>\n"
            f"Лимит приветов/час: <b>{row.max_greets_hour or 20}</b>\n"
            f"Привет: {hello}\n\n"
            f"<b>Текст подарка:</b>\n{gift_preview}\n"
        )
        if row.last_error:
            text += f"\n⚠️ <code>{row.last_error[:200]}</code>\n"
        run_btn = "⏹ Стоп" if is_online(row.id) else "▶️ Старт"
        kb = [
            [
                InlineKeyboardButton(text=run_btn, callback_data=f"adm:ub:run:{row.id}"),
                InlineKeyboardButton(text="🔑 Войти (код)", callback_data=f"adm:ub:code:{row.id}"),
            ],
            [
                InlineKeyboardButton(text="✏️ Привет", callback_data=f"adm:ub:hello:{row.id}"),
                InlineKeyboardButton(text="🎁 Подарок", callback_data=f"adm:ub:gift:{row.id}"),
            ],
            [InlineKeyboardButton(text="🗑 Удалить", callback_data=f"adm:ub:del:{row.id}")],
            [InlineKeyboardButton(text="⬅️ К списку", callback_data="adm:ub")],
        ]
        return text, InlineKeyboardMarkup(inline_keyboard=kb)


async def _show(target: Message | CallbackQuery, text: str, kb: InlineKeyboardMarkup) -> None:
    if isinstance(target, CallbackQuery) and target.message:
        try:
            await target.message.edit_text(text, parse_mode="HTML", reply_markup=kb)
        except Exception:
            await target.message.answer(text, parse_mode="HTML", reply_markup=kb)
        await target.answer()
        return
    if isinstance(target, Message):
        await target.answer(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data == "adm:ub")
async def ub_root(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    text, kb = await _ub_list_view()
    await _show(callback, text, kb)


@router.callback_query(F.data.regexp(r"^adm:ub:v:\d+$"))
async def ub_view(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    aid = int(callback.data.split(":")[-1])
    card = await _ub_card(aid)
    if not card:
        await callback.answer("Не найден", show_alert=True)
        return
    await _show(callback, *card)


@router.callback_query(F.data == "adm:ub:add")
async def ub_add(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminSG.wait_ub_phone)
    await callback.answer()
    if callback.message:
        await callback.message.answer(
            "Отправь номер в международном формате.\nПример: <code>+79001234567</code>",
            parse_mode="HTML",
        )


@router.message(AdminSG.wait_ub_phone, F.text)
async def ub_phone_msg(message: Message, state: FSMContext) -> None:
    if (message.text or "").strip() in SKIP:
        return
    try:
        row = await create_account(message.text or "")
    except ValueError as exc:
        await message.answer(str(exc))
        return
    try:
        hint = await begin_login(row.id)
    except Exception as exc:
        await message.answer(f"Не удалось отправить код: <code>{exc}</code>", parse_mode="HTML")
        await state.clear()
        text, kb = await _ub_list_view()
        await message.answer(text, parse_mode="HTML", reply_markup=kb)
        return
    await state.update_data(ub_id=row.id)
    await state.set_state(AdminSG.wait_ub_code)
    await message.answer(f"{hint}\nАккаунт: <code>{row.phone}</code>", parse_mode="HTML")


@router.callback_query(F.data.regexp(r"^adm:ub:code:\d+$"))
async def ub_resend_code(callback: CallbackQuery, state: FSMContext) -> None:
    aid = int(callback.data.split(":")[-1])
    try:
        hint = await begin_login(aid)
    except Exception as exc:
        await callback.answer(str(exc)[:180], show_alert=True)
        return
    await state.update_data(ub_id=aid)
    await state.set_state(AdminSG.wait_ub_code)
    await callback.answer()
    if callback.message:
        await callback.message.answer(hint)


@router.message(AdminSG.wait_ub_code, F.text)
async def ub_code_msg(message: Message, state: FSMContext) -> None:
    if (message.text or "").strip() in SKIP:
        return
    data = await state.get_data()
    aid = int(data.get("ub_id") or 0)
    if not aid:
        await state.clear()
        await message.answer("Сессия сброшена. Открой юзер-бота заново.")
        return
    try:
        result = await submit_code(aid, message.text or "")
    except Exception as exc:
        await message.answer(f"Ошибка кода: <code>{exc}</code>", parse_mode="HTML")
        return
    if "2FA" in result or "пароль" in result.lower():
        await state.set_state(AdminSG.wait_ub_2fa)
        await message.answer(result)
        return
    await state.clear()
    await message.answer(f"✅ {result}")
    card = await _ub_card(aid)
    if card:
        await message.answer(card[0], parse_mode="HTML", reply_markup=card[1])


@router.message(AdminSG.wait_ub_2fa, F.text)
async def ub_2fa_msg(message: Message, state: FSMContext) -> None:
    if (message.text or "").strip() in SKIP:
        return
    data = await state.get_data()
    aid = int(data.get("ub_id") or 0)
    if not aid:
        await state.clear()
        return
    password = message.text or ""
    try:
        await message.delete()
    except Exception:
        pass
    try:
        result = await submit_password(aid, password)
    except Exception as exc:
        await message.answer(f"Ошибка 2FA: <code>{exc}</code>", parse_mode="HTML")
        return
    await state.clear()
    await message.answer(f"✅ {result}")
    card = await _ub_card(aid)
    if card:
        await message.answer(card[0], parse_mode="HTML", reply_markup=card[1])


@router.callback_query(F.data.regexp(r"^adm:ub:run:\d+$"))
async def ub_run(callback: CallbackQuery) -> None:
    aid = int(callback.data.split(":")[-1])
    try:
        if is_online(aid):
            await set_active(aid, False)
            await callback.answer("Остановлен")
        else:
            await set_active(aid, True)
            await callback.answer("Запущен")
    except Exception as exc:
        await callback.answer(str(exc)[:180], show_alert=True)
        return
    card = await _ub_card(aid)
    if card:
        await _show(callback, *card)


@router.callback_query(F.data.regexp(r"^adm:ub:hello:\d+$"))
async def ub_hello_ask(callback: CallbackQuery, state: FSMContext) -> None:
    aid = int(callback.data.split(":")[-1])
    await state.update_data(ub_id=aid)
    await state.set_state(AdminSG.wait_ub_hello)
    await callback.answer()
    if callback.message:
        await callback.message.answer("Пришли новый текст приветствия (можно HTML / прем-эмодзи).")


@router.message(AdminSG.wait_ub_hello)
async def ub_hello_msg(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    aid = int(data.get("ub_id") or 0)
    await _merge_premium(message)
    text = message.html_text or message.text or message.caption or ""
    await update_texts(aid, hello_text=text)
    await state.clear()
    await message.answer("Привет сохранён.")
    card = await _ub_card(aid)
    if card:
        await message.answer(card[0], parse_mode="HTML", reply_markup=card[1])


@router.callback_query(F.data.regexp(r"^adm:ub:gift:\d+$"))
async def ub_gift_ask(callback: CallbackQuery, state: FSMContext) -> None:
    aid = int(callback.data.split(":")[-1])
    await state.update_data(ub_id=aid)
    await state.set_state(AdminSG.wait_ub_gift)
    await callback.answer()
    if callback.message:
        await callback.message.answer(
            "Пришли текст подарка с <b>жирным</b> и прем-эмодзи — сохраню как есть.\n"
            "Или HTML: <code>&lt;b&gt;…&lt;/b&gt;</code>, "
            "<code>&lt;tg-emoji emoji-id=\"ID\"&gt;🎁&lt;/tg-emoji&gt;</code>",
            parse_mode="HTML",
        )


@router.message(AdminSG.wait_ub_gift)
async def ub_gift_msg(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    aid = int(data.get("ub_id") or 0)
    await _merge_premium(message)
    plain, ents = entities_from_aiogram(message)
    html = message.html_text or plain
    await update_texts(
        aid,
        gift_text=html if not ents else plain,
        gift_parse_mode="HTML",
        gift_entities=dumps_entities(ents) if ents else "[]",
    )
    # If we have entities from the message, prefer plain+entities for Telethon fidelity
    if ents:
        await update_texts(aid, gift_text=plain, gift_entities=dumps_entities(ents))
    await state.clear()
    await message.answer("🎁 Текст подарка сохранён.")
    card = await _ub_card(aid)
    if card:
        await message.answer(card[0], parse_mode="HTML", reply_markup=card[1])


@router.callback_query(F.data.regexp(r"^adm:ub:del:\d+$"))
async def ub_del(callback: CallbackQuery) -> None:
    aid = int(callback.data.split(":")[-1])
    await delete_account(aid)
    await callback.answer("Удалён")
    text, kb = await _ub_list_view()
    await _show(callback, text, kb)
