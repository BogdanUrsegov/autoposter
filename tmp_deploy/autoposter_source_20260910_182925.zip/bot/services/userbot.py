"""Юзербот на Telethon: логин, воронка ЛС, таймеры, антифлуд."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import random
import re
from datetime import timedelta
from typing import Any
from urllib.parse import urlparse

from sqlalchemy import select
from telethon import TelegramClient, events
from telethon.errors import (
    FloodWaitError,
    PhoneCodeExpiredError,
    PhoneCodeInvalidError,
    SessionPasswordNeededError,
    UserDeactivatedBanError,
    UserDeactivatedError,
)
from telethon.sessions import StringSession

from bot.services.userbot_format import prepare_send_payload
from config import SESSIONS_DIR, settings
from database import SessionLocal
from database.crud import utcnow
from database.models import UserBotAccount, UserBotLead

logger = logging.getLogger(__name__)

HELLO_DEFAULT = "привеееет, ты хочешь подарочек?"
NUDGE_30_TEXT = "ну что там???"
NUDGE_6H_TEXT = "эййййй, скоро кончатся призы!!!"
NUDGE_24H_TEXT = "ну что там???"

GIFT_WAIT_SECONDS = 3600
NUDGE_30_SECONDS = 30 * 60
NUDGE_6H_SECONDS = 6 * 3600
NUDGE_24H_SECONDS = 24 * 3600

MIN_SEND_GAP = 4.5
REPLY_DELAY = (2.8, 7.5)
TYPING_SECONDS = (1.2, 2.8)
WATCHER_TICK = 20
DEFAULT_MAX_GREETS_HOUR = 20

_PHONE_RE = re.compile(r"^\+?\d{10,15}$")

_clients: dict[int, TelegramClient] = {}
_client_tasks: dict[int, asyncio.Task] = {}
_locks: dict[int, asyncio.Lock] = {}
_last_send: dict[int, float] = {}
_pending_auth: dict[int, dict[str, Any]] = {}
_watcher_task: asyncio.Task | None = None
_started = False


def normalize_phone(raw: str) -> str:
    digits = re.sub(r"[^\d+]", "", (raw or "").strip())
    if digits.startswith("00"):
        digits = "+" + digits[2:]
    if digits.isdigit():
        digits = "+" + digits
    return digits


def phone_ok(phone: str) -> bool:
    return bool(_PHONE_RE.match(phone or ""))


def _proxy_tuple():
    url = settings.proxy_url
    if not url:
        return None
    try:
        import socks
    except ImportError:
        logger.warning("PySocks не установлен — юзербот без прокси")
        return None
    parsed = urlparse(url)
    host = parsed.hostname
    port = parsed.port
    if not host or not port:
        return None
    scheme = (parsed.scheme or "socks5").lower()
    if scheme in ("socks5", "socks5h"):
        kind = socks.SOCKS5
    elif scheme in ("socks4", "socks4a"):
        kind = socks.SOCKS4
    else:
        kind = socks.HTTP
    return (kind, host, port, True, parsed.username, parsed.password)


def _require_api() -> tuple[int, str]:
    api_id = int(settings.api_id or 0)
    api_hash = (settings.api_hash or "").strip()
    if api_id <= 0 or not api_hash:
        raise RuntimeError(
            "Заполни API_ID и API_HASH в .env (my.telegram.org → API development tools)"
        )
    return api_id, api_hash


def _make_client(session: str = "") -> TelegramClient:
    api_id, api_hash = _require_api()
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    client = TelegramClient(
        StringSession(session or ""),
        api_id,
        api_hash,
        proxy=_proxy_tuple(),
        device_model="iPhone 14 Pro",
        system_version="17.5.1",
        app_version="10.14.5",
        lang_code="ru",
        system_lang_code="ru-RU",
        flood_sleep_threshold=24,
        connection_retries=5,
        retry_delay=2,
        auto_reconnect=True,
        sequential_updates=True,
    )
    return client


def _lock_for(account_id: int) -> asyncio.Lock:
    lock = _locks.get(account_id)
    if lock is None:
        lock = asyncio.Lock()
        _locks[account_id] = lock
    return lock


async def _pace(account_id: int) -> None:
    loop = asyncio.get_running_loop()
    now = loop.time()
    prev = _last_send.get(account_id, 0.0)
    wait = MIN_SEND_GAP - (now - prev)
    if wait > 0:
        await asyncio.sleep(wait + random.uniform(0.2, 1.1))
    _last_send[account_id] = loop.time()


async def _human_pause() -> None:
    await asyncio.sleep(random.uniform(*REPLY_DELAY))


async def _typing(client: TelegramClient, peer) -> None:
    try:
        async with client.action(peer, "typing"):
            await asyncio.sleep(random.uniform(*TYPING_SECONDS))
    except Exception:
        await asyncio.sleep(random.uniform(0.4, 1.0))


async def _safe_send(
    client: TelegramClient,
    account_id: int,
    peer,
    text: str,
    *,
    parse_mode: str | None = None,
    entities_json: str | None = None,
) -> bool:
    body, entities = prepare_send_payload(text, parse_mode, entities_json)
    if not (body or "").strip():
        return False
    await _pace(account_id)
    await _typing(client, peer)
    try:
        kwargs: dict[str, Any] = {"entity": peer, "message": body}
        if entities:
            kwargs["formatting_entities"] = entities
        await client.send_message(**kwargs)
        return True
    except FloodWaitError as exc:
        delay = min(int(exc.seconds) + 1, 120)
        logger.warning("userbot %s FloodWait %ss", account_id, delay)
        await asyncio.sleep(delay)
        try:
            await client.send_message(peer, body, formatting_entities=entities or None)
            return True
        except Exception:
            logger.exception("userbot %s send retry failed", account_id)
            return False
    except (UserDeactivatedError, UserDeactivatedBanError):
        await _mark_error(account_id, "аккаунт деактивирован / бан")
        await stop_account(account_id)
        return False
    except Exception as exc:
        logger.exception("userbot %s send failed: %s", account_id, exc)
        return False


async def _set_status(account_id: int, status: str, error: str = "", **fields) -> None:
    async with SessionLocal() as session:
        row = await session.get(UserBotAccount, account_id)
        if not row:
            return
        row.status = status
        if error is not None:
            row.last_error = (error or "")[:500]
        for key, value in fields.items():
            if hasattr(row, key):
                setattr(row, key, value)
        row.updated_at = utcnow()
        await session.commit()


async def _mark_error(account_id: int, error: str) -> None:
    await _set_status(account_id, "error", error, is_active=False)


async def _bump_greet_counter(account: UserBotAccount) -> bool:
    """True если лимит часа не превышен и счётчик увеличен."""
    key = utcnow().strftime("%Y%m%d%H")
    limit = int(account.max_greets_hour or DEFAULT_MAX_GREETS_HOUR)
    if account.greets_hour_key != key:
        account.greets_hour_key = key
        account.greets_hour = 0
    if account.greets_hour >= max(1, limit):
        return False
    account.greets_hour += 1
    return True


async def get_account(account_id: int) -> UserBotAccount | None:
    async with SessionLocal() as session:
        return await session.get(UserBotAccount, account_id)


async def list_accounts() -> list[UserBotAccount]:
    async with SessionLocal() as session:
        rows = (
            await session.execute(select(UserBotAccount).order_by(UserBotAccount.id.desc()))
        ).scalars().all()
        return list(rows)


async def create_account(phone: str) -> UserBotAccount:
    phone = normalize_phone(phone)
    if not phone_ok(phone):
        raise ValueError("Некорректный номер. Формат: +79001234567")
    async with SessionLocal() as session:
        exists = (
            await session.execute(select(UserBotAccount).where(UserBotAccount.phone == phone))
        ).scalar_one_or_none()
        if exists:
            raise ValueError("Этот номер уже добавлен")
        row = UserBotAccount(
            phone=phone,
            status="new",
            hello_text=HELLO_DEFAULT,
            is_active=False,
        )
        session.add(row)
        await session.commit()
        await session.refresh(row)
        return row


async def delete_account(account_id: int) -> None:
    await stop_account(account_id)
    _pending_auth.pop(account_id, None)
    async with SessionLocal() as session:
        row = await session.get(UserBotAccount, account_id)
        if row:
            await session.delete(row)
            await session.commit()


async def begin_login(account_id: int) -> str:
    """Отправляет код на телефон. Возвращает подсказку для админа."""
    _require_api()
    await stop_account(account_id)
    async with SessionLocal() as session:
        row = await session.get(UserBotAccount, account_id)
        if not row:
            raise ValueError("Аккаунт не найден")
        phone = row.phone
        session_str = row.session_string or ""

    client = _make_client(session_str)
    await client.connect()
    try:
        if await client.is_user_authorized():
            me = await client.get_me()
            saved = client.session.save()
            await _set_status(
                account_id,
                "ready",
                "",
                session_string=saved,
                tg_id=me.id if me else None,
                username=(me.username or "") if me else "",
                first_name=(me.first_name or "") if me else "",
                is_active=True,
            )
            await client.disconnect()
            await start_account(account_id)
            return "Сессия уже валидна — аккаунт запущен"
        sent = await client.send_code_request(phone)
        _pending_auth[account_id] = {
            "client": client,
            "phone": phone,
            "phone_code_hash": sent.phone_code_hash,
        }
        await _set_status(account_id, "wait_code", "")
        return "Код отправлен в Telegram / SMS. Введи код сюда."
    except Exception as exc:
        await client.disconnect()
        _pending_auth.pop(account_id, None)
        await _mark_error(account_id, str(exc))
        raise


async def submit_code(account_id: int, code: str) -> str:
    code = re.sub(r"\D", "", code or "")
    if len(code) < 4:
        raise ValueError("Код слишком короткий")
    pending = _pending_auth.get(account_id)
    if not pending:
        raise ValueError("Сначала нажми «Войти» — код ещё не запрашивали")
    client: TelegramClient = pending["client"]
    try:
        await client.sign_in(
            phone=pending["phone"],
            code=code,
            phone_code_hash=pending["phone_code_hash"],
        )
    except SessionPasswordNeededError:
        await _set_status(account_id, "wait_2fa", "")
        return "Нужен облачный пароль (2FA). Введи пароль."
    except PhoneCodeInvalidError as exc:
        raise ValueError("Неверный код") from exc
    except PhoneCodeExpiredError as exc:
        _pending_auth.pop(account_id, None)
        try:
            await client.disconnect()
        except Exception:
            pass
        await _set_status(account_id, "error", "код истёк")
        raise ValueError("Код истёк — нажми «Войти» ещё раз") from exc
    except Exception:
        raise

    return await _finish_auth(account_id, client)


async def submit_password(account_id: int, password: str) -> str:
    password = (password or "").strip()
    if not password:
        raise ValueError("Пароль пустой")
    pending = _pending_auth.get(account_id)
    if not pending:
        raise ValueError("Нет незавершённого входа — нажми «Войти»")
    client: TelegramClient = pending["client"]
    try:
        await client.sign_in(password=password)
    except Exception as exc:
        raise ValueError(f"Пароль не принят: {exc}") from exc
    return await _finish_auth(account_id, client)


async def _finish_auth(account_id: int, client: TelegramClient) -> str:
    me = await client.get_me()
    session_str = client.session.save()
    await client.disconnect()
    _pending_auth.pop(account_id, None)
    await _set_status(
        account_id,
        "ready",
        "",
        session_string=session_str,
        tg_id=me.id if me else None,
        username=(me.username or "") if me else "",
        first_name=(me.first_name or "") if me else "",
        is_active=True,
    )
    await start_account(account_id)
    name = (me.username and f"@{me.username}") or (me.first_name if me else "")
    return f"Готово, вошли как {name or me.id}. Юзербот запущен."


async def update_texts(
    account_id: int,
    *,
    hello_text: str | None = None,
    gift_text: str | None = None,
    gift_parse_mode: str | None = None,
    gift_entities: str | None = None,
) -> None:
    async with SessionLocal() as session:
        row = await session.get(UserBotAccount, account_id)
        if not row:
            return
        if hello_text is not None:
            row.hello_text = hello_text.strip() or HELLO_DEFAULT
        if gift_text is not None:
            row.gift_text = gift_text
        if gift_parse_mode is not None:
            row.gift_parse_mode = gift_parse_mode
        if gift_entities is not None:
            row.gift_entities = gift_entities
        row.updated_at = utcnow()
        await session.commit()


async def set_active(account_id: int, active: bool) -> None:
    if active:
        await start_account(account_id)
    else:
        await stop_account(account_id)
        await _set_status(account_id, "stopped", "", is_active=False)


async def start_account(account_id: int) -> None:
    async with _lock_for(account_id):
        if account_id in _clients:
            return
        async with SessionLocal() as session:
            row = await session.get(UserBotAccount, account_id)
            if not row or not (row.session_string or "").strip():
                raise ValueError("Нет сессии — сначала войди по коду")
            session_str = row.session_string

        client = _make_client(session_str)
        await client.connect()
        if not await client.is_user_authorized():
            await client.disconnect()
            await _mark_error(account_id, "сессия невалидна — войди заново")
            raise ValueError("Сессия умерла — войди заново")

        me = await client.get_me()

        @client.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
        async def _on_private(event: events.NewMessage.Event) -> None:
            await _handle_incoming(account_id, client, event)

        _clients[account_id] = client
        task = _client_tasks.get(account_id)
        if task is None or task.done():
            _client_tasks[account_id] = asyncio.create_task(
                client.run_until_disconnected(),
                name=f"userbot-client-{account_id}",
            )
        await _set_status(
            account_id,
            "ready",
            "",
            is_active=True,
            tg_id=me.id if me else None,
            username=(me.username or "") if me else "",
            first_name=(me.first_name or "") if me else "",
            session_string=client.session.save(),
        )
        logger.info("userbot %s started as %s", account_id, me.id if me else "?")
        await _ensure_watcher()


async def _ensure_watcher() -> None:
    global _watcher_task, _started
    if _watcher_task is None or _watcher_task.done():
        _watcher_task = asyncio.create_task(watcher_loop(), name="userbot-watcher")
    _started = True


async def stop_account(account_id: int) -> None:
    async with _lock_for(account_id):
        task = _client_tasks.pop(account_id, None)
        if task and not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task
        client = _clients.pop(account_id, None)
        if client:
            try:
                await client.disconnect()
            except Exception:
                logger.exception("userbot %s disconnect", account_id)


async def stop_all() -> None:
    global _watcher_task, _started
    ids = list(_clients.keys())
    for account_id in ids:
        await stop_account(account_id)
    for pending in list(_pending_auth.values()):
        client = pending.get("client")
        if client:
            try:
                await client.disconnect()
            except Exception:
                pass
    _pending_auth.clear()
    if _watcher_task and not _watcher_task.done():
        _watcher_task.cancel()
    _watcher_task = None
    _started = False


async def start_all_active() -> None:
    global _watcher_task, _started
    if not settings.api_id or not (settings.api_hash or "").strip():
        logger.warning("API_ID/API_HASH не заданы — юзерботы не запущены")
        return
    async with SessionLocal() as session:
        rows = (
            await session.execute(
                select(UserBotAccount).where(
                    UserBotAccount.is_active.is_(True),
                    UserBotAccount.session_string != "",
                )
            )
        ).scalars().all()
        ids = [r.id for r in rows]
    for account_id in ids:
        try:
            await start_account(account_id)
        except Exception:
            logger.exception("failed to start userbot %s", account_id)
    if _watcher_task is None or _watcher_task.done():
        _watcher_task = asyncio.create_task(watcher_loop(), name="userbot-watcher")
    _started = True


async def _handle_incoming(
    account_id: int,
    client: TelegramClient,
    event: events.NewMessage.Event,
) -> None:
    try:
        sender = await event.get_sender()
    except Exception:
        return
    if not sender or getattr(sender, "bot", False) or getattr(sender, "is_self", False):
        return
    peer_id = int(sender.id)
    username = (getattr(sender, "username", None) or "")[:64]
    first_name = (getattr(sender, "first_name", None) or "")[:128]
    now = utcnow()

    async with SessionLocal() as session:
        account = await session.get(UserBotAccount, account_id)
        if not account or not account.is_active:
            return
        lead = (
            await session.execute(
                select(UserBotLead).where(
                    UserBotLead.account_id == account_id,
                    UserBotLead.peer_tg_id == peer_id,
                )
            )
        ).scalar_one_or_none()

        if lead is None:
            if not await _bump_greet_counter(account):
                account.updated_at = now
                await session.commit()
                logger.info("userbot %s hour limit, skip %s", account_id, peer_id)
                return
            lead = UserBotLead(
                account_id=account_id,
                peer_tg_id=peer_id,
                username=username,
                first_name=first_name,
                stage="pending_hello",
                last_user_at=now,
            )
            session.add(lead)
            await session.commit()
            await session.refresh(lead)
            hello = (account.hello_text or HELLO_DEFAULT).strip() or HELLO_DEFAULT
            await _human_pause()
            ok = await _safe_send(client, account_id, event.chat_id, hello)
            async with SessionLocal() as s2:
                lead2 = await s2.get(UserBotLead, lead.id)
                acc2 = await s2.get(UserBotAccount, account_id)
                if not lead2:
                    return
                if ok:
                    lead2.stage = "greeted"
                    lead2.greeted_at = utcnow()
                    lead2.gift_due_at = utcnow() + timedelta(seconds=GIFT_WAIT_SECONDS)
                    lead2.last_bot_at = utcnow()
                else:
                    lead2.stage = "error"
                if acc2:
                    acc2.updated_at = utcnow()
                await s2.commit()
            return

        lead.last_user_at = now
        lead.username = username or lead.username
        lead.first_name = first_name or lead.first_name

        if lead.blocked:
            await session.commit()
            return

        if lead.stage == "greeted":
            # человек ответил на привет — сразу подарок
            gift_text = account.gift_text or ""
            gift_mode = account.gift_parse_mode or "HTML"
            gift_ents = account.gift_entities or "[]"
            lead.stage = "sending_gift"
            await session.commit()
            if not (gift_text or "").strip():
                async with SessionLocal() as s2:
                    lead2 = await s2.get(UserBotLead, lead.id)
                    if lead2:
                        lead2.stage = "done"
                        lead2.gift_sent_at = utcnow()
                        await s2.commit()
                return
            await _human_pause()
            ok = await _safe_send(
                client,
                account_id,
                event.chat_id,
                gift_text,
                parse_mode=gift_mode,
                entities_json=gift_ents,
            )
            async with SessionLocal() as s2:
                lead2 = await s2.get(UserBotLead, lead.id)
                if not lead2:
                    return
                if ok:
                    lead2.stage = "gifted"
                    lead2.gift_sent_at = utcnow()
                    lead2.last_bot_at = utcnow()
                else:
                    lead2.stage = "greeted"
                    lead2.gift_due_at = utcnow() + timedelta(minutes=5)
                await s2.commit()
            return

        if lead.stage == "gifted":
            # ответил после подарка — больше не пушим
            lead.stage = "done"
            await session.commit()
            return

        await session.commit()


async def _process_due(account_id: int, client: TelegramClient) -> None:
    now = utcnow()
    async with SessionLocal() as session:
        account = await session.get(UserBotAccount, account_id)
        if not account or not account.is_active:
            return
        leads = (
            await session.execute(
                select(UserBotLead).where(
                    UserBotLead.account_id == account_id,
                    UserBotLead.blocked.is_(False),
                    UserBotLead.stage.in_(("greeted", "gifted")),
                )
            )
        ).scalars().all()
        jobs: list[tuple[int, str]] = []
        for lead in leads:
            if lead.stage == "greeted" and lead.gift_due_at and lead.gift_due_at <= now:
                jobs.append((lead.id, "gift"))
            elif lead.stage == "gifted" and lead.gift_sent_at:
                elapsed = (now - lead.gift_sent_at).total_seconds()
                if not lead.nudge_30_sent and elapsed >= NUDGE_30_SECONDS:
                    jobs.append((lead.id, "n30"))
                elif lead.nudge_30_sent and not lead.nudge_6h_sent and elapsed >= NUDGE_6H_SECONDS:
                    jobs.append((lead.id, "n6h"))
                elif lead.nudge_6h_sent and not lead.nudge_24h_sent and elapsed >= NUDGE_24H_SECONDS:
                    jobs.append((lead.id, "n24h"))

        gift_text = account.gift_text or ""
        gift_mode = account.gift_parse_mode or "HTML"
        gift_ents = account.gift_entities or "[]"

    for lead_id, kind in jobs:
        async with SessionLocal() as session:
            lead = await session.get(UserBotLead, lead_id)
            if not lead or lead.blocked:
                continue
            peer = lead.peer_tg_id
            if kind == "gift":
                if lead.stage != "greeted":
                    continue
                if not (gift_text or "").strip():
                    lead.stage = "done"
                    lead.gift_sent_at = utcnow()
                    await session.commit()
                    continue
                lead.stage = "sending_gift"
                await session.commit()
                ok = await _safe_send(
                    client, account_id, peer, gift_text, parse_mode=gift_mode, entities_json=gift_ents
                )
                async with SessionLocal() as s2:
                    lead2 = await s2.get(UserBotLead, lead_id)
                    if not lead2:
                        continue
                    if ok:
                        lead2.stage = "gifted"
                        lead2.gift_sent_at = utcnow()
                        lead2.last_bot_at = utcnow()
                    else:
                        lead2.stage = "greeted"
                        lead2.gift_due_at = utcnow() + timedelta(minutes=10)
                    await s2.commit()
                continue

            text = {
                "n30": NUDGE_30_TEXT,
                "n6h": NUDGE_6H_TEXT,
                "n24h": NUDGE_24H_TEXT,
            }.get(kind)
            if not text or lead.stage != "gifted":
                continue
            # если человек писал после подарка — не пушим (страховка)
            if lead.last_user_at and lead.gift_sent_at and lead.last_user_at > lead.gift_sent_at:
                lead.stage = "done"
                await session.commit()
                continue
            await session.commit()
            ok = await _safe_send(client, account_id, peer, text)
            async with SessionLocal() as s2:
                lead2 = await s2.get(UserBotLead, lead_id)
                if not lead2:
                    continue
                if ok:
                    lead2.last_bot_at = utcnow()
                    if kind == "n30":
                        lead2.nudge_30_sent = True
                    elif kind == "n6h":
                        lead2.nudge_6h_sent = True
                    elif kind == "n24h":
                        lead2.nudge_24h_sent = True
                        lead2.stage = "done"
                await s2.commit()


async def watcher_loop() -> None:
    while True:
        try:
            for account_id, client in list(_clients.items()):
                if not client.is_connected():
                    try:
                        await client.connect()
                    except Exception:
                        logger.exception("userbot %s reconnect", account_id)
                        continue
                try:
                    await _process_due(account_id, client)
                except Exception:
                    logger.exception("userbot watcher %s", account_id)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("userbot watcher tick")
        await asyncio.sleep(WATCHER_TICK)


def status_label(row: UserBotAccount) -> str:
    if row.is_active and row.id in _clients:
        return "онлайн"
    return {
        "new": "новый",
        "wait_code": "ждёт код",
        "wait_2fa": "ждёт 2FA",
        "ready": "готов",
        "stopped": "стоп",
        "error": "ошибка",
    }.get(row.status or "", row.status or "?")


def is_online(account_id: int) -> bool:
    return account_id in _clients


async def userbot_startup() -> None:
    await start_all_active()


async def userbot_shutdown() -> None:
    await stop_all()
